import * as React from 'react';
import { 
    NavigationContainer 
} from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { RootStackParamList } from './RootStackParamList';
import Bankpayment  from './Bankpayment';
import Cartpage  from './Cartpage';
import Congratspage  from './Congratspage';
import Editprofilepage  from './Editprofilepage';
import History from './History';
import Homepage  from './Homepage';
import Landingpage  from './Landingpage';
import Login  from './Login';
import Orderpage  from './Orderpage';
import Payment  from './Payment';
import Profile  from './Profilepage';
import Sayurpage  from './Sayurpage';
import Signup  from './Signup';
import Timelinepage  from './Timelinepage';

const Stack = createNativeStackNavigator<RootStackParamList>();

const AppNavigation = () => {

    return (
        <NavigationContainer>
            <Stack.Navigator 
                screenOptions={{ headerShown: false }} 
                initialRouteName={"Login"}
                >
                <Stack.Screen name={"Bankpayment"} component={Bankpayment} />
                <Stack.Screen name={"Cartpage"} component={Cartpage} />
                <Stack.Screen name={"Congratspage"} component={Congratspage} />
                <Stack.Screen name={"Editprofilepage"} component={Editprofilepage} />
                <Stack.Screen name={"History"} component={History} />
                <Stack.Screen name={"Homepage"} component={Homepage} />
                <Stack.Screen name={"Landingpage"} component={Landingpage} />
                <Stack.Screen name={"Login"} component={Login} />
                <Stack.Screen name={"Orderpage"} component={Orderpage} />
                <Stack.Screen name={"Payment"} component={Payment} />
                <Stack.Screen name={"Profile"} component={Profile} />
                <Stack.Screen name={"Sayurpage"} component={Sayurpage} />
                <Stack.Screen name={"Signup"} component={Signup} />
                <Stack.Screen name={"Timelinepage"} component={Timelinepage} />
            </Stack.Navigator>
        </NavigationContainer>
    )
}

export default AppNavigation;