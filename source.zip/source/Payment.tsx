import React from "react";
import {View,Text,Image,TextInput, StyleSheet, Pressable, Linking} from "react-native";
import { 
  NavigationContainer 
} from '@react-navigation/native';
import { Checkbox } from "react-native-paper";
import ovo from  './asset/ovo.png';
import bank from  './asset/bank.png';
import gopay from  './asset/gopay.png';
import shopeepay from  './asset/shopee.png';



const Payment = () => {

  return(
    <View style={styles.home}>
      <View style={styles.atas}>
        <Text style={styles.back}>Back</Text>
        <Text style={styles.payment}>Payment</Text>
      </View>
      <View style={styles.baris}>
        <Text style={styles.txt}>Bank Payment</Text>
        <Image source={bank}></Image>
      </View>
      <View style={styles.baris}>
        <Text style={styles.txt}>Ovo</Text>
        <Image source={ovo}></Image>
      </View>
      <View style={styles.baris}>
        <Text style={styles.txt}>Gopay</Text>
        <Image source={gopay}></Image>
      </View>
      <View style={styles.baris}>
        <Text style={styles.txt}>Shopeepay</Text>
        <Image source={shopeepay}></Image>
      </View>
    </View>
  );
};


const styles = StyleSheet.create({
  home :{
    height:1000, 
    backgroundColor:'#B4DAEB'
  },
  atas :{
    flexDirection : "row",
    marginTop : 15,
    marginLeft : 23,
  },
  back :{
    color : "black",
    marginTop : 13
  },
  payment :{
    color : "black",
    marginLeft : 80,
    fontSize : 32,
    alignItems : "center",
    marginBottom : 10
  },
  baris :{
    flexDirection : "row",
    borderWidth : 1,
    backgroundColor : "white",
    marginTop : 30,
    marginHorizontal : 30,
    justifyContent : "space-between",
    borderRadius : 30,
    paddingHorizontal : 10
  },
  txt :{
    color : "black",
    marginTop : 10,
    fontSize : 18
  },
  sopi :{
    paddingBottom : -2
  }
});


export default Payment;