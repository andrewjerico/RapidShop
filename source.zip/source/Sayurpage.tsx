import React from "react";
import {View,Text,Image,TextInput, StyleSheet, Pressable, Linking} from "react-native";
import { 
  NavigationContainer 
} from '@react-navigation/native';
import cart from  './asset/cart.png';
import bayam from  './asset/bayam.png';
import kangkung from  './asset/kangkung.png';
import brokoli from  './asset/brokoli.png';
import buncis from  './asset/buncis.png';
import kacangpanjang from  './asset/kacangpanjang.png';
import sawi from  './asset/sawi.png';
import home from  './asset/blueHome.png';
import time from  './asset/time.png';
import prof from  './asset/prof.png';
import { Checkbox } from "react-native-paper";


const Sayurpage = () => {

  return(
    <View style={styles.home}>
      <View style={styles.atas}>
        <Text style={styles.back}>Back</Text>
        <TextInput style={styles.box} placeholder ="Search"></TextInput>
        <Image source={cart} style={styles.cart}></Image>
      </View>
      <View style={styles.baris}>
        <View>
          <Image source={bayam}></Image>
          <Text style={styles.txt}>Bayam</Text>
        </View>
        <View style={styles.kanan}>
          <Image source={kangkung}></Image>
          <Text style={styles.txt}>Kangkung</Text>
        </View>
      </View>
      <View style={styles.baris}>
        <View>
          <Image source={kacangpanjang}></Image>
          <Text style={styles.txt}>Kacang panjang</Text>
        </View>
        <View style={styles.kanan}>
          <Image source={sawi}></Image>
          <Text style={styles.txt}>Sawi</Text>
        </View>
      </View>
      <View style={styles.baris}>
        <View>
          <Image source={buncis}></Image>
          <Text style={styles.txt}>Buncis</Text>
        </View>
        <View style={styles.kanan}>
          <Image source={brokoli}></Image>
          <Text style={styles.txt}>Brokoli</Text>
        </View>
      </View>

      <View style={styles.foot}>
        <Image source={home} style={styles.homes}></Image>
        <Image source={time}></Image>
        <Image source={prof}></Image>
      </View>

    </View>
  );
};


const styles = StyleSheet.create({
  home :{
    height:1000, 
    backgroundColor:'#B4DAEB'
  },
  atas :{
    flexDirection : "row",
    marginTop : 15,
    marginLeft : 23,
  },
  back :{
    color : "black",
    marginTop : 13
  },
  box :{
    marginLeft : 10,
    borderWidth : 1,
    backgroundColor : '#FFFFFF',
    borderRadius : 30,
    width : 260,
    paddingLeft : 20
  },
  cart :{
    marginTop : 4
  },
  baris :{
    flexDirection : "row",
    marginLeft : 18,
    marginTop : 10
  },
  kanan :{
    marginLeft : 23
  },
  txt :{
    textAlign : "center",
    color : "black",
    fontSize : 16
  },
  foot :{
    marginTop : 14,
    flexDirection : "row",
    justifyContent : "space-evenly",
    backgroundColor : "#FFFFFF"
  },
  homes :{
    marginTop : 4
  }
});


export default Sayurpage;