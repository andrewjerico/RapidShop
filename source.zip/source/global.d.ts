// declare module "*.png" {
//     export default "" as string;
//   }