import React from "react";
import {View,Text,Image,TextInput, StyleSheet, Pressable, Linking} from "react-native";
import { 
  NavigationContainer 
} from '@react-navigation/native';
import cart from  './asset/cart.png';
import sayur from  './asset/sayur.png';
import buah from  './asset/buah.png';
import daging from  './asset/daging.png';
import snack from  './asset/snack.png';
import chocolate from  './asset/chocolate.png';
import susu from  './asset/susu.png';
import home from  './asset/blueHome.png';
import time from  './asset/time.png';
import prof from  './asset/prof.png';
import { Checkbox } from "react-native-paper";


const Homepage = () => {

  return(
    <View style={styles.home}>
      <View style={styles.atas}>
        <TextInput style={styles.box} placeholder ="Search"></TextInput>
        <Image source={cart} style={styles.cart}></Image>
      </View>
      <View style={styles.baris}>
        <View>
          <Image source={sayur}></Image>
          <Text style={styles.txt}>Sayur</Text>
        </View>
        <View style={styles.kanan}>
          <Image source={buah}></Image>
          <Text style={styles.txt}>Buah</Text>
        </View>
      </View>
      <View style={styles.baris}>
        <View>
          <Image source={daging}></Image>
          <Text style={styles.txt}>Daging</Text>
        </View>
        <View style={styles.kanan}>
          <Image source={snack}></Image>
          <Text style={styles.txt}>Snack</Text>
        </View>
      </View>
      <View style={styles.baris}>
        <View>
          <Image source={chocolate}></Image>
          <Text style={styles.txt}>Chocolate</Text>
        </View>
        <View style={styles.kanan}>
          <Image source={susu}></Image>
          <Text style={styles.txt}>Susu</Text>
        </View>
      </View>

      <View style={styles.foot}>
        <Image source={home} style={styles.homes}></Image>
        <Image source={time}></Image>
        <Image source={prof}></Image>
      </View>

    </View>
  );
};


const styles = StyleSheet.create({
  home :{
    height:1000, 
    backgroundColor:'#B4DAEB'
  },
  atas :{
    flexDirection : "row",
    marginTop : 15
  },
  box :{
    marginLeft : 20,
    borderWidth : 1,
    backgroundColor : '#FFFFFF',
    borderRadius : 30,
    width : 310,
    paddingLeft : 20
  },
  cart :{
    marginTop : 4
  },
  baris :{
    flexDirection : "row",
    marginLeft : 18,
    marginTop : 10
  },
  kanan :{
    marginLeft : 23
  },
  txt :{
    textAlign : "center",
    color : "black",
    fontSize : 16
  },
  foot :{
    marginTop : 14,
    flexDirection : "row",
    justifyContent : "space-evenly",
    backgroundColor : "#FFFFFF"
  },
  homes :{
    marginTop : 4
  }
});


export default Homepage;