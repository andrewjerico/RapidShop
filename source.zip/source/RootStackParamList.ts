export type RootStackParamList = {
    Bankpayment : undefined;
    Cartpage   : undefined;
    Congratspage   : undefined;
    Editprofilepage   : undefined;
    History  : undefined;
    Homepage   : undefined;
    Landingpage   : undefined;
    Login    : undefined;
    Orderpage  : undefined;
    Payment   : undefined;
    Profile   : undefined;
    Sayurpage   : undefined;
    Signup   : undefined;
    Timelinepage : undefined;
    }