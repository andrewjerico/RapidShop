import React from "react";
import {View,Text,Image,TextInput, StyleSheet, Pressable, Linking} from "react-native";
import { 
  NavigationContainer 
} from '@react-navigation/native';
import { Checkbox } from "react-native-paper";
import cart from  './asset/cart.png';
import home from  './asset/home.png';
import time from  './asset/blueTime.png';
import prof from  './asset/prof.png';
import miniKangkung from './asset/miniKangkung.png';
import miniLocation from './asset/miniLocation.png';

const Timelinepage = () => {

  return(
    <View style={styles.home}>
      <View style={styles.atas}>
        <Text style={styles.back}>Back</Text>
        <Text style={styles.timeline}>Timeline</Text>
        <Image source={cart} style={styles.cart}></Image>
      </View>
      <View style={styles.baris}>
        <Text style={styles.txt1}>On Going</Text>
        <Text style={styles.txt2}>History</Text>
      </View>
      <View style={styles.main}>
        <Text style={styles.txt4}>   Senin, 14 - 03 - 2022                      Rp. 15.000</Text>
        <View style={styles.line}>
        </View>
        <View style={styles.order}>
          <Image source={miniKangkung} style={styles.items}></Image>
          <Text style={styles.txt3}>Kangkung(1)...+2 items</Text>
        </View>
        <View style={styles.line}>
        </View>
        <View style={styles.location}>
          <Image source={miniLocation} style={styles.miniLoc}></Image>
          <Text style={styles.txt5}>Jl Kerinci 5 Jakarta</Text>

        </View>
      </View>
      
    


      <View style={styles.foot}>
        <Image source={home} style={styles.homes}></Image>
        <Image source={time}></Image>
        <Image source={prof}></Image>
      </View>

    </View>
  );
};


const styles = StyleSheet.create({
  home :{
    height:1000, 
    backgroundColor:'#B4DAEB'
  },
  atas :{
    flexDirection : "row",
    marginTop : 15,
    marginLeft : 23
  },
  back :{
    color : "black",
    marginTop : 13
  },
  timeline :{
    color : "black",
    marginLeft : 80,
    fontSize : 32,
    alignItems : "center",
    marginBottom : 10
  },
  cart :{
    marginLeft : 60,
    marginTop : 2
  },
  baris :{
    flexDirection : "row",
    justifyContent : "center",
    marginTop : 10,
  },
  txt1 :{
    borderWidth : 1,
    paddingHorizontal : 45,
    paddingVertical : 5,
    borderRadius : 10,
    backgroundColor : "#032B6B",
    color : "white"
  },
  txt2 :{
    borderWidth : 1,
    paddingHorizontal : 50,
    paddingVertical : 5,
    borderRadius : 10,
    marginLeft :5,
    backgroundColor : "white",
    color : "black"
  },
  main :{
    marginHorizontal : 46,
    marginTop : 7,
    backgroundColor : "white",
    borderRadius : 15,
    
  },
  txt4 :{
    color : "black"
  },
  line :{
    borderWidth : 1,
    borderBottomColor : "black"
  },
  order :{
    flexDirection : "row",
    marginTop : 10,
    marginLeft : 10
  },
  items :{

  },
  txt3 :{
    marginLeft : 15,
    marginTop : 12,
    color : "black"
  },
  location :{
    marginTop : 10,
    marginLeft : 10,
    flexDirection : "row",
    marginBottom : 10
  },
  miniLoc :{

  },
  txt5 :{
    color : "black",
    marginLeft : 10
  },
  foot :{
    marginTop : 427,
    flexDirection : "row",
    justifyContent : "space-evenly",
    backgroundColor : "#FFFFFF"
  },
  homes :{
    marginTop : 4
  }
});


export default Timelinepage;